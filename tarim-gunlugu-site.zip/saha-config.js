// Supabase ayarları. Hem saha.html hem saha-yonetim.html bu dosyayı okur.
// Bunlar Tarım Günlüğü (index.html) ile aynı Supabase projesidir.
// Publishable/anon key herkese açık anahtardır, sorun değil. service_role anahtarını ASLA buraya yazmayın.
window.SAHA_CONFIG = {
  SUPABASE_URL: "https://wxsjkiduuhxkdaeiiplg.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_YMiMP5rmxGttFpxFm6zqTw_htYjDNaa",
  BUCKET: "saha-pdf",
  TABLE: "saha_kayitlari"
};
